function openLoginPage(){
    window.location.href = "Login.php"
}