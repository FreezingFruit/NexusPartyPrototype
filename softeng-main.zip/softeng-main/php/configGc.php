<?php

$conn = mysqli_connect('localhost','root','','groupchat_db');

?>